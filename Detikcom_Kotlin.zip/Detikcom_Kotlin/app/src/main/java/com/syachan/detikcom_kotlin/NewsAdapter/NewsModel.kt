package com.syachan.detikcom_kotlin.NewsAdapter

import com.syachan.detikcom_kotlin.R

data class news(var title: String, var desc: String, var photo: Int)

object NewsModel {
    val newslist = listOf<news>(
            news("Pasat ramai dikunjungi warga meskipun wabah covid-19 belum dinyarakan usai",
    "detikcom | 1 jam yang lalu",
                R.drawable.img_news1),


        news("Kapal Nelayan menyalurkan bansos masyarakat Sulawesi",
            "detikcom | 1 jam yang lalu",
            R.drawable.img_news2),

        news("Macet mulai terjadi di wilayah jalur pemudik Semarang",
            "detikcom | 2 jam yang lalu",
            R.drawable.img_news3),

        news("Jelang new normal Jakarta macet lagi",
            "ditikcom | 3 jam yang lalu",
            R.drawable.img_news4),

        news("Dukun Indonesia perangi covid-19, sampoerna donasi ventilator dan APD Full set",
            "detikcom | 4 jam yang lalu",
            R.drawable.img_news5),

        news("Saat risma jelaskan soal penanganan corona pada kepala BNPB dan Menkes",
            "detikcom | 5jam yang lalu",
            R.drawable.img_news6),

        news("Banjir keritik ke truap yang kerahkan militer usai demo gegorgr floyd",
            "detikcom | 6 jam yang lalu",
            R.drawable.img_news7),

        news("Mengapa aksi demo damai kasusu george floyd bisa berubah jadi kerusuhan?",
            "detikcom | 7jam yang lalu",
            R.drawable.img_news8),

        news("2 opsi bagi calon jamaah haji yang tidak jadi berangkat tahun ini",
            "detikcom | 9 jam yang lalu",
            R.drawable.img_news9)

    )
}